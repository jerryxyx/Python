#Read me

There are 6 python file in this assignment.

##AmericanPricer.py
Using trinomial tree to simulate American option pricing model. Moreover, when volatility equals to zero, degrade to a single strand with drift.

##BlackSholes.py
Defining the Black Scholes Merton price model

##ImpliedVolatility.py
Using Classic Brent method or Newton method(see in annotation but not safe as Brent method) to solve the function of pricing model. 

##JimGatheralSVI.py
Using none-linear least squares to fit the volatility smile

##volatilitySmile.py
Plot the volatility smile based on the data. See the picture: volatility smile

##volatilitySurface.py
plot the 3d surface of implied volatility. One can find the term structure and smile in it. See pictures.


 
Language: Python(Python3)
Modules: pandas(not inherit), time, os
Output: Excel file with 2 sheets. One for RH ranking, the other for stocks that listed less than 5 days.

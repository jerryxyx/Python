.. ImpVol documentation master file, created by
   sphinx-quickstart on Fri Dec 19 10:41:45 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. toctree::
   :maxdepth: 1

.. automodule:: impvol.impvol
	:members: imp_vol, impvol_bisection, impvol_table, lfmoneyness, blackscholes_norm

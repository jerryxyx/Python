.. image:: https://travis-ci.org/khrapovs/impvol.svg
    :target: https://travis-ci.org/khrapovs/impvol

.. image:: https://readthedocs.org/projects/impvol/badge/?version=latest
	:target: https://readthedocs.org/projects/impvol/?badge=latest
	:alt: Documentation Status

Black-Scholes Implied Volatility
================================

Documentation
-------------

`Documentation <http://impvol.readthedocs.org/en/latest/>`_

Installation
------------

::

  pip install git+git://github.com/khrapovs/impvol
